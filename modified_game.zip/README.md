
  # Harm.ee Game Development Plan

  This is a code bundle for Harm.ee Game Development Plan. The original project is available at https://www.figma.com/design/Ga6T0B6JvIVLIjD4qrZ5cl/Harm.ee-Game-Development-Plan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  