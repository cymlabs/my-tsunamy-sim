import { useState } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { LandingScreen } from './components/LandingScreen';
import { GameHUD } from './components/GameHUD';
import { GameOverScreen } from './components/GameOverScreen';
import { LeaderboardScreen } from './components/LeaderboardScreen';
import { SoundManager } from './components/SoundManager';
import { Toaster } from 'sonner@2.0.3';

export type GameMode = 'quick-vent' | 'combo-chase' | 'chill-sandbox' | 'daily-challenge';
export type GameState = 'landing' | 'playing' | 'game-over' | 'leaderboard';

export interface GameStats {
  score: number;
  combo: number;
  maxCombo: number;
  hits: number;
  timeElapsed: number;
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>('landing');
  const [gameMode, setGameMode] = useState<GameMode | null>(null);
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    hits: 0,
    timeElapsed: 0,
  });
  const [coins, setCoins] = useState(250);
  const [rank, setRank] = useState('Bronze Brawler');

  const startGame = (mode: GameMode) => {
    setGameMode(mode);
    setStats({
      score: 0,
      combo: 0,
      maxCombo: 0,
      hits: 0,
      timeElapsed: 0,
    });
    setGameState('playing');
  };

  const endGame = (finalStats: GameStats) => {
    setStats(finalStats);
    setCoins(prev => prev + Math.floor(finalStats.score / 100));
    setGameState('game-over');
  };

  const returnToLanding = () => {
    setGameState('landing');
    setGameMode(null);
  };

  const showLeaderboard = () => {
    setGameState('leaderboard');
  };

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#1a0f0f]">
      <SoundManager />
      <Toaster position="top-center" theme="dark" />
      
      {gameState === 'landing' && (
        <LandingScreen 
          onStartGame={startGame}
          onShowLeaderboard={showLeaderboard}
          coins={coins}
          rank={rank}
        />
      )}

      {gameState === 'playing' && gameMode && (
        <>
          <GameCanvas 
            gameMode={gameMode}
            onGameEnd={endGame}
            onUpdateStats={setStats}
          />
          <GameHUD 
            stats={stats}
            gameMode={gameMode}
            onQuit={returnToLanding}
          />
        </>
      )}

      {gameState === 'game-over' && gameMode && (
        <GameOverScreen 
          stats={stats}
          gameMode={gameMode}
          onPlayAgain={() => startGame(gameMode)}
          onReturnToMenu={returnToLanding}
        />
      )}

      {gameState === 'leaderboard' && (
        <LeaderboardScreen 
          onBack={returnToLanding}
        />
      )}
    </div>
  );
}
