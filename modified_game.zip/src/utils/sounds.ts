// Simple sound system using Web Audio API
let audioContext: AudioContext | null = null;
let sounds: Map<string, AudioBuffer> = new Map();

export function initializeSounds() {
  if (typeof window === 'undefined') return;
  
  audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  
  // Generate procedural sounds
  generateHitSounds();
}

function generateHitSounds() {
  if (!audioContext) return;

  // Light hit - short, soft thud
  const lightBuffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.1, audioContext.sampleRate);
  const lightData = lightBuffer.getChannelData(0);
  for (let i = 0; i < lightData.length; i++) {
    const t = i / audioContext.sampleRate;
    lightData[i] = Math.sin(2 * Math.PI * 200 * t) * Math.exp(-t * 20) * 0.3;
  }
  sounds.set('hit-light', lightBuffer);

  // Medium hit - punchier with harmonics
  const mediumBuffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.15, audioContext.sampleRate);
  const mediumData = mediumBuffer.getChannelData(0);
  for (let i = 0; i < mediumData.length; i++) {
    const t = i / audioContext.sampleRate;
    mediumData[i] = (
      Math.sin(2 * Math.PI * 150 * t) * 0.5 +
      Math.sin(2 * Math.PI * 300 * t) * 0.3
    ) * Math.exp(-t * 15) * 0.4;
  }
  sounds.set('hit-medium', mediumBuffer);

  // Heavy hit - deep bass with impact
  const heavyBuffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.2, audioContext.sampleRate);
  const heavyData = heavyBuffer.getChannelData(0);
  for (let i = 0; i < heavyData.length; i++) {
    const t = i / audioContext.sampleRate;
    heavyData[i] = (
      Math.sin(2 * Math.PI * 80 * t) * 0.6 +
      Math.sin(2 * Math.PI * 160 * t) * 0.3 +
      (Math.random() - 0.5) * 0.1 * Math.exp(-t * 30)
    ) * Math.exp(-t * 10) * 0.5;
  }
  sounds.set('hit-heavy', heavyBuffer);
}

export function playSound(soundName: string, volume: number = 1) {
  if (!audioContext || !sounds.has(soundName)) return;

  const source = audioContext.createBufferSource();
  const gainNode = audioContext.createGain();
  
  source.buffer = sounds.get(soundName)!;
  gainNode.gain.value = volume;
  
  source.connect(gainNode);
  gainNode.connect(audioContext.destination);
  
  source.start(0);
}
