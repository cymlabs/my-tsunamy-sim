import { motion } from 'motion/react';
import { ArrowLeft, Trophy, Medal, Award, Crown, Star } from 'lucide-react';

interface LeaderboardScreenProps {
  onBack: () => void;
}

// Mock leaderboard data
const leaderboardData = [
  { rank: 1, name: 'StressSlayer', score: 25430, combo: 87, icon: Crown, color: '#FFD23F', gradient: 'from-[#FFD23F] to-[#FF6B35]' },
  { rank: 2, name: 'ZenMaster', score: 22100, combo: 72, icon: Trophy, color: '#C0C0C0', gradient: 'from-gray-300 to-gray-400' },
  { rank: 3, name: 'ComboKing', score: 19850, combo: 95, icon: Medal, color: '#CD7F32', gradient: 'from-orange-400 to-orange-600' },
  { rank: 4, name: 'VentVibes', score: 18200, combo: 64 },
  { rank: 5, name: 'PunchPro', score: 16900, combo: 58 },
  { rank: 6, name: 'FuryFist', score: 15400, combo: 51 },
  { rank: 7, name: 'ChillChamp', score: 14800, combo: 47 },
  { rank: 8, name: 'ReliefRider', score: 13200, combo: 43 },
  { rank: 9, name: 'StrikeForce', score: 12600, combo: 39 },
  { rank: 10, name: 'BuddyBeater', score: 11900, combo: 36 },
];

export function LeaderboardScreen({ onBack }: LeaderboardScreenProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#1a0520] to-[#0a0a0a] overflow-auto">
      {/* Animated background orbs */}
      <motion.div
        className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: 'radial-gradient(circle, #FF6B35, transparent)' }}
        animate={{
          x: [0, 50, 0],
          y: [0, -30, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      <motion.div
        className="absolute bottom-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: 'radial-gradient(circle, #00D9FF, transparent)' }}
        animate={{
          x: [0, -50, 0],
          y: [0, 30, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <div className="relative min-h-full flex flex-col p-8 max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-6 mb-16">
          <motion.button
            className="p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl hover:bg-white/20 transition-colors"
            whileHover={{ scale: 1.1, x: -5 }}
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </motion.button>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-white tracking-tight" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
              Leaderboard
            </h1>
            <p className="text-white/60 tracking-[0.3em] uppercase text-xs">
              Season 3 • Global Rankings
            </p>
          </motion.div>
        </div>

        {/* Podium - Top 3 */}
        <div className="grid grid-cols-3 gap-6 mb-16 items-end">
          {[1, 0, 2].map((index) => {
            const player = leaderboardData[index];
            const Icon = player.icon!;
            const height = index === 0 ? 'h-80' : 'h-64';
            const delay = index * 0.15;
            
            return (
              <motion.div
                key={player.rank}
                className={`${height} relative`}
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              >
                {/* Glow effect */}
                <motion.div
                  className={`absolute inset-0 rounded-3xl blur-xl bg-gradient-to-br ${player.gradient} opacity-30`}
                  animate={{ 
                    scale: [1, 1.05, 1],
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                />

                <div 
                  className={`relative h-full bg-white/5 backdrop-blur-xl border-2 rounded-3xl p-6 flex flex-col items-center justify-end overflow-hidden`}
                  style={{ borderColor: player.color + '80' }}
                >
                  {/* Rank badge */}
                  <motion.div 
                    className={`absolute -top-6 w-16 h-16 rounded-2xl border-4 flex items-center justify-center bg-gradient-to-br ${player.gradient} shadow-2xl`}
                    style={{ borderColor: 'rgba(255, 255, 255, 0.3)' }}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Animated stars for rank 1 */}
                  {player.rank === 1 && (
                    <>
                      <motion.div
                        className="absolute top-20 left-6"
                        animate={{ 
                          y: [0, -10, 0],
                          rotate: [0, 180, 360],
                        }}
                        transition={{ duration: 3, repeat: Infinity }}
                      >
                        <Star className="w-4 h-4 text-[#FFD23F]" fill="#FFD23F" />
                      </motion.div>
                      <motion.div
                        className="absolute top-24 right-6"
                        animate={{ 
                          y: [0, -15, 0],
                          rotate: [0, -180, -360],
                        }}
                        transition={{ duration: 4, repeat: Infinity }}
                      >
                        <Star className="w-5 h-5 text-[#FFD23F]" fill="#FFD23F" />
                      </motion.div>
                    </>
                  )}

                  <div className="text-center mb-6">
                    <div className="text-white text-2xl mb-2">{player.name}</div>
                    <div className="text-white/40 text-xs tracking-widest uppercase">
                      Rank #{player.rank}
                    </div>
                  </div>

                  <div className="text-center">
                    <div className={`text-transparent bg-clip-text bg-gradient-to-r ${player.gradient} text-3xl mb-2`}>
                      {player.score.toLocaleString()}
                    </div>
                    <div className="text-white/60 text-sm">
                      Max Combo: <span className="text-white">{player.combo}</span>
                    </div>
                  </div>

                  {/* Decorative gradient */}
                  <div 
                    className={`absolute bottom-0 left-0 right-0 h-32 opacity-10 bg-gradient-to-t ${player.gradient}`}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Rest of leaderboard */}
        <div className="space-y-3 mb-12">
          {leaderboardData.slice(3).map((player, index) => (
            <motion.div
              key={player.rank}
              className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-2xl flex items-center justify-between hover:bg-white/10 hover:border-white/30 transition-all group"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + (index * 0.05) }}
              whileHover={{ scale: 1.02, x: 10 }}
            >
              <div className="flex items-center gap-6">
                {/* Rank number */}
                <div className="w-14 h-14 bg-white/5 border border-white/20 rounded-xl flex items-center justify-center group-hover:bg-white/10 transition-colors">
                  <span className="text-white text-xl">#{player.rank}</span>
                </div>
                
                {/* Player info */}
                <div>
                  <div className="text-white text-lg mb-1">{player.name}</div>
                  <div className="text-white/50 text-sm">
                    Max Combo: <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] to-[#8338EC]">{player.combo}</span>
                  </div>
                </div>
              </div>

              {/* Score */}
              <div className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD23F] text-2xl">
                {player.score.toLocaleString()}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Season info */}
        <motion.div
          className="bg-white/5 backdrop-blur-xl border border-white/20 p-8 text-center rounded-3xl relative overflow-hidden"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-[#FF6B35]/10 via-[#00D9FF]/10 to-[#8338EC]/10"
            animate={{ 
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{ duration: 5, repeat: Infinity }}
          />
          
          <p className="text-white text-lg mb-2 relative z-10">
            Season ends in <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD23F] to-[#FF6B35]">14 days</span>
          </p>
          <p className="text-white/60 relative z-10">
            Top 100 players will receive exclusive rewards
          </p>
        </motion.div>
      </div>
    </div>
  );
}