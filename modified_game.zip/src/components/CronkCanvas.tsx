import { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * CronkCanvas renders a simple 3D representation of Cronk the raccoon using
 * primitive geometries in Three.js. The model gently idles and reacts to
 * pointer movement on the landing page. Colours have been chosen to evoke
 * a soft, approachable character while remaining neutral enough to blend
 * into the overall Harm.ee palette. This component is mounted behind
 * other UI on the landing screen and does not capture pointer events.
 */
export function CronkCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene, camera and renderer setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0a0a0a, 5, 20);
    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    );
    camera.position.set(0, 1, 6);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // Lighting to softly illuminate Cronk
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    const keyLight = new THREE.DirectionalLight(0xfff3e0, 0.6);
    keyLight.position.set(5, 10, 5);
    scene.add(keyLight);
    const rimLight = new THREE.DirectionalLight(0xded2ff, 0.4);
    rimLight.position.set(-4, 3, -4);
    scene.add(rimLight);

    // Group to hold Cronk parts
    const cronkGroup = new THREE.Group();

    // Body – capsule geometry tinted a soft grey
    const bodyGeom = new THREE.CapsuleGeometry(1.0, 2.5, 12, 24);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x807f85,
      roughness: 0.6,
      metalness: 0.2,
      emissive: 0x2a2a2a,
      emissiveIntensity: 0.1,
    });
    const body = new THREE.Mesh(bodyGeom, bodyMat);
    cronkGroup.add(body);

    // Head – sphere positioned atop the body
    const headGeom = new THREE.SphereGeometry(0.8, 32, 32);
    const headMat = new THREE.MeshStandardMaterial({
      color: 0x807f85,
      roughness: 0.5,
      metalness: 0.2,
      emissive: 0x2a2a2a,
      emissiveIntensity: 0.1,
    });
    const head = new THREE.Mesh(headGeom, headMat);
    head.position.set(0, 2.1, 0);
    cronkGroup.add(head);

    // Mask – torus around the face for the raccoon mask
    const maskGeom = new THREE.TorusGeometry(0.6, 0.25, 16, 32);
    const maskMat = new THREE.MeshStandardMaterial({
      color: 0x1f1f1f,
      roughness: 0.4,
      metalness: 0.3,
      emissive: 0x0d0d0d,
      emissiveIntensity: 0.3,
    });
    const mask = new THREE.Mesh(maskGeom, maskMat);
    mask.rotation.x = Math.PI / 2;
    mask.position.set(0, 2.1, 0.6);
    cronkGroup.add(mask);

    // Eyes – small dark spheres with slight emissive highlight
    const eyeGeom = new THREE.SphereGeometry(0.12, 16, 16);
    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0x000000,
      emissive: 0x000000,
      emissiveIntensity: 0.8,
    });
    const leftEye = new THREE.Mesh(eyeGeom, eyeMat);
    leftEye.position.set(-0.25, 2.25, 0.9);
    const rightEye = new THREE.Mesh(eyeGeom, eyeMat);
    rightEye.position.set(0.25, 2.25, 0.9);
    cronkGroup.add(leftEye);
    cronkGroup.add(rightEye);

    // Ears – cones slightly rotated
    const earGeom = new THREE.ConeGeometry(0.3, 0.6, 12);
    const earMat = new THREE.MeshStandardMaterial({
      color: 0x414042,
      roughness: 0.5,
      metalness: 0.2,
      emissive: 0x1a1a1a,
      emissiveIntensity: 0.05,
    });
    const leftEar = new THREE.Mesh(earGeom, earMat);
    leftEar.position.set(-0.6, 2.8, 0);
    leftEar.rotation.set(-Math.PI / 8, 0, Math.PI / 12);
    const rightEar = new THREE.Mesh(earGeom, earMat);
    rightEar.position.set(0.6, 2.8, 0);
    rightEar.rotation.set(-Math.PI / 8, 0, -Math.PI / 12);
    cronkGroup.add(leftEar);
    cronkGroup.add(rightEar);

    // Tail – series of tapered cylinders with alternating stripes
    const tailGroup = new THREE.Group();
    const tailColors = [0x807f85, 0x2d2c2f];
    for (let i = 0; i < 5; i++) {
      const topRadius = 0.35 - i * 0.04;
      const bottomRadius = 0.3 - i * 0.04;
      const segGeom = new THREE.CylinderGeometry(topRadius, bottomRadius, 0.4, 12);
      const segMat = new THREE.MeshStandardMaterial({
        color: tailColors[i % 2],
        roughness: 0.5,
        metalness: 0.2,
      });
      const seg = new THREE.Mesh(segGeom, segMat);
      seg.position.y = -i * 0.4;
      tailGroup.add(seg);
    }
    tailGroup.rotation.z = Math.PI / 4;
    tailGroup.position.set(0, -1.6, -0.8);
    cronkGroup.add(tailGroup);

    // Add Cronk to scene
    scene.add(cronkGroup);

    // Animation state
    let frame = 0;
    const animate = () => {
      frame += 0.01;
      // Gentle breathing motion
      cronkGroup.position.y = Math.sin(frame * 2) * 0.1;
      cronkGroup.rotation.y = Math.sin(frame) * 0.3;
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    animate();

    // Pointer handler to tilt Cronk toward the cursor
    const handlePointer = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const xNorm = (clientX / window.innerWidth) * 2 - 1;
      const yNorm = (clientY / window.innerHeight) * 2 - 1;
      cronkGroup.rotation.x = yNorm * 0.2;
      cronkGroup.rotation.z = -xNorm * 0.2;
    };
    window.addEventListener('mousemove', handlePointer);
    window.addEventListener('touchmove', handlePointer);

    // Resize handling
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup on unmount
    return () => {
      window.removeEventListener('mousemove', handlePointer);
      window.removeEventListener('touchmove', handlePointer);
      window.removeEventListener('resize', handleResize);
      container.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      /*
       * Position Cronk above the background gradients but behind other UI. A
       * higher z-index ensures the 3D model isn’t hidden by the animated
       * gradient layers on the landing page.
       */
      className="absolute inset-0 pointer-events-none z-10"
      aria-hidden="true"
    />
  );
}