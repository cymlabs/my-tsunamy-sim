import { motion } from 'motion/react';
import { Trophy, Sparkles, Zap, Flame } from 'lucide-react';
import { GameMode } from '../App';
import { ParticleSystem } from './ParticleSystem';
import { CronkCanvas } from './CronkCanvas';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LandingScreenProps {
  onStartGame: (mode: GameMode) => void;
  onShowLeaderboard: () => void;
  coins: number;
  rank: string;
}

const gameModes = [
  {
    id: 'quick-vent' as GameMode,
    title: 'Quick Vent',
    description: 'Let it all out. 60 seconds of pure stress relief.',
    color: '#FF6B35',
    gradient: 'from-[#FF6B35] to-[#FF006E]',
    icon: Flame,
  },
  {
    id: 'combo-chase' as GameMode,
    title: 'Combo Chase',
    description: 'Keep the streak alive. How high can you go?',
    color: '#00D9FF',
    gradient: 'from-[#00D9FF] to-[#8338EC]',
    icon: Zap,
  },
  {
    id: 'chill-sandbox' as GameMode,
    title: 'Chill Sandbox',
    description: 'No pressure, just vibe. Endless zen mode.',
    color: '#8338EC',
    gradient: 'from-[#8338EC] to-[#FF006E]',
    icon: Sparkles,
  },
  {
    id: 'daily-challenge' as GameMode,
    title: 'Daily Challenge',
    description: 'Special mission. Earn bonus rewards.',
    color: '#FFD23F',
    gradient: 'from-[#FFD23F] to-[#FF6B35]',
    badge: 'NEW',
    icon: Trophy,
  },
];

export function LandingScreen({ onStartGame, onShowLeaderboard, coins, rank }: LandingScreenProps) {
  return (
    <div className="relative w-full h-full overflow-hidden">
      <ParticleSystem />

      {/* Render a 3D Cronk model behind all other content. It uses pointer-events-none so it won't interfere with interactions. */}
      <CronkCanvas />
      
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#1a0520] to-[#0a0a0a]" />
      
      {/* Animated mesh gradient overlay */}
      <motion.div 
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `url(https://images.unsplash.com/photo-1612072254406-ba7813ff5c1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdyYWRpZW50JTIwdGV4dHVyZXxlbnwxfHx8fDE3NjY2ODAzOTV8MA&ixlib=rb-4.1.0&q=80&w=1080)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          mixBlendMode: 'overlay',
        }}
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.3, 0.4, 0.3],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Noise texture */}
      <div 
        className="absolute inset-0 opacity-20 mix-blend-overlay"
        style={{
          backgroundImage: `url(https://images.unsplash.com/photo-1687432517546-3a7bcef593ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG5vaXNlJTIwZ3JhaW58ZW58MXx8fHwxNzY2NzgxNjY3fDA&ixlib=rb-4.1.0&q=80&w=1080)`,
          backgroundSize: '400px',
        }}
      />

      {/* Glow orbs */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-30"
        style={{ background: 'radial-gradient(circle, #FF6B35 0%, transparent 70%)' }}
        animate={{
          x: [0, 50, 0],
          y: [0, -30, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      <motion.div
        className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-30"
        style={{ background: 'radial-gradient(circle, #00D9FF 0%, transparent 70%)' }}
        animate={{
          x: [0, -50, 0],
          y: [0, 30, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Main content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-8 py-12 max-w-7xl mx-auto">
        {/* Title with animated gradient */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.h1 
            className="relative inline-block mb-6"
            style={{ 
              fontSize: 'clamp(4rem, 15vw, 12rem)',
              lineHeight: 0.9,
              background: 'linear-gradient(135deg, #FF6B35 0%, #FFD23F 25%, #00D9FF 50%, #8338EC 75%, #FF006E 100%)',
              backgroundSize: '200% 200%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
            animate={{
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'linear',
            }}
          >
            HARM.EE
            
            {/* Glow effect */}
            <motion.span
              className="absolute inset-0 blur-2xl opacity-50"
              style={{ 
                background: 'linear-gradient(135deg, #FF6B35, #FFD23F, #00D9FF, #8338EC, #FF006E)',
                backgroundSize: '200% 200%',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: 'linear',
              }}
            />
          </motion.h1>
          
          <motion.p 
            className="text-white/60 tracking-[0.5em] uppercase text-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            Vent • Breathe • Rise
          </motion.p>
        </motion.div>

        {/* Mode cards - reimagined */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-5xl mb-12">
          {gameModes.map((mode, index) => {
            const Icon = mode.icon;
            return (
              <motion.button
                key={mode.id}
                className="relative group overflow-hidden bg-white/5 backdrop-blur-xl border border-white/10 p-8 text-left rounded-3xl"
                initial={{ opacity: 0, y: 30, rotateX: -10 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ 
                  delay: 0.1 * index, 
                  duration: 0.6,
                  ease: [0.16, 1, 0.3, 1]
                }}
                whileHover={{ 
                  scale: 1.03,
                  y: -8,
                  rotateX: 5,
                  transition: { duration: 0.3 }
                }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onStartGame(mode.id)}
              >
                {/* Gradient overlay */}
                <motion.div 
                  className={`absolute inset-0 bg-gradient-to-br ${mode.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500`}
                />

                {/* Animated border glow */}
                <motion.div
                  className="absolute inset-0 rounded-3xl"
                  style={{
                    background: `linear-gradient(135deg, ${mode.color}, transparent)`,
                    opacity: 0,
                  }}
                  whileHover={{ opacity: 0.3 }}
                  transition={{ duration: 0.3 }}
                />

                <div className="relative z-10 flex items-start gap-4">
                  {/* Icon */}
                  <motion.div
                    className="flex-shrink-0 w-16 h-16 rounded-2xl flex items-center justify-center"
                    style={{ 
                      background: `linear-gradient(135deg, ${mode.color}40, ${mode.color}20)`,
                      border: `2px solid ${mode.color}60`,
                    }}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className="w-8 h-8" style={{ color: mode.color }} />
                  </motion.div>

                  <div className="flex-1">
                    {mode.badge && (
                      <motion.div 
                        className="inline-block px-3 py-1 rounded-full text-xs mb-2"
                        style={{ background: `${mode.color}30`, color: mode.color }}
                        animate={{ scale: [1, 1.05, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        {mode.badge}
                      </motion.div>
                    )}
                    <h3 className="text-white text-3xl mb-2">
                      {mode.title}
                    </h3>
                    <p className="text-white/60 text-sm leading-relaxed">
                      {mode.description}
                    </p>
                  </div>
                </div>

                {/* Corner accent */}
                <div 
                  className="absolute bottom-0 right-0 w-32 h-32 opacity-10 group-hover:opacity-20 transition-opacity"
                  style={{
                    background: `radial-gradient(circle at top left, ${mode.color}, transparent 70%)`,
                  }}
                />
              </motion.button>
            );
          })}
        </div>

        {/* Bottom bar - redesigned */}
        <motion.div
          className="w-full max-w-5xl flex items-center justify-between px-8 py-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex items-center gap-8">
            <motion.div
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-white/40 text-xs tracking-widest uppercase mb-1">Rank</div>
              <div className="text-white text-lg">{rank}</div>
            </motion.div>
            
            <div className="w-px h-12 bg-white/10" />
            
            <motion.div
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-white/40 text-xs tracking-widest uppercase mb-1">Coins</div>
              <motion.div 
                className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD23F] to-[#FF6B35] text-lg"
                key={coins}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
              >
                {coins}
              </motion.div>
            </motion.div>
          </div>

          <motion.button
            className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#FF6B35] to-[#FF006E] text-white rounded-2xl relative overflow-hidden group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onShowLeaderboard}
          >
            <motion.div
              className="absolute inset-0 bg-white/20"
              initial={{ x: '-100%' }}
              whileHover={{ x: '100%' }}
              transition={{ duration: 0.5 }}
            />
            <Trophy className="w-5 h-5 relative z-10" />
            <span className="relative z-10">Leaderboard</span>
          </motion.button>
        </motion.div>
      </div>

      {/* Floating badge */}
      <motion.div
        className="absolute top-12 right-12 w-32 h-32"
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ delay: 0.6, type: 'spring', stiffness: 200 }}
        whileHover={{ scale: 1.1, rotate: 10 }}
      >
        <div className="relative w-full h-full">
          <motion.div
            className="absolute inset-0 rounded-full bg-gradient-to-br from-[#FFD23F] to-[#FF6B35] blur-xl opacity-60"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#FFD23F] to-[#FF6B35] border-4 border-white/20 flex items-center justify-center backdrop-blur-sm">
            <div className="text-center">
              <div className="text-white text-xs tracking-widest">DAILY</div>
              <div className="text-white text-xs">RELIEF</div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}