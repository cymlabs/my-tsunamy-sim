import { motion } from 'motion/react';
import { RotateCcw, Home, Trophy, Sparkles } from 'lucide-react';
import { GameMode, GameStats } from '../App';

interface GameOverScreenProps {
  stats: GameStats;
  gameMode: GameMode;
  onPlayAgain: () => void;
  onReturnToMenu: () => void;
}

export function GameOverScreen({ stats, gameMode, onPlayAgain, onReturnToMenu }: GameOverScreenProps) {
  const getRank = (score: number) => {
    if (score > 10000) return { rank: 'S', color: '#FFD23F', gradient: 'from-[#FFD23F] to-[#FF6B35]' };
    if (score > 7500) return { rank: 'A', color: '#00D9FF', gradient: 'from-[#00D9FF] to-[#8338EC]' };
    if (score > 5000) return { rank: 'B', color: '#8338EC', gradient: 'from-[#8338EC] to-[#FF006E]' };
    if (score > 2500) return { rank: 'C', color: '#FF6B35', gradient: 'from-[#FF6B35] to-[#FF006E]' };
    return { rank: 'D', color: '#666', gradient: 'from-gray-600 to-gray-400' };
  };

  const { rank, color, gradient } = getRank(stats.score);

  const motivationalMessages = [
    "You're stronger than you think.",
    "Every breath is a fresh start.",
    "Progress, not perfection.",
    "You showed up. That's what matters.",
    "Tomorrow is a new day.",
    "Be kind to yourself.",
  ];

  const randomMessage = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#1a0520] to-[#0a0a0a] flex items-center justify-center p-8 overflow-auto">
      {/* Animated background orbs */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: `radial-gradient(circle, ${color}, transparent)` }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.2, 0.3, 0.2],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
        }}
      />

      <motion.div
        className="max-w-3xl w-full relative z-10"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      >
        {/* Rank badge */}
        <motion.div
          className="flex justify-center mb-12"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 15 }}
        >
          <div className="relative">
            {/* Glow effect */}
            <motion.div
              className={`absolute inset-0 rounded-full blur-2xl bg-gradient-to-br ${gradient}`}
              animate={{ 
                scale: [1, 1.3, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            
            {/* Badge */}
            <div 
              className={`relative w-40 h-40 rounded-full border-8 flex items-center justify-center bg-gradient-to-br ${gradient}`}
              style={{ borderColor: 'rgba(255, 255, 255, 0.2)' }}
            >
              <div className="text-white text-7xl drop-shadow-2xl">{rank}</div>
            </div>

            {/* Sparkles */}
            <motion.div
              className="absolute -top-4 -right-4"
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="w-8 h-8" style={{ color }} />
            </motion.div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.h2
          className="text-center text-white mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
        >
          Session Complete
        </motion.h2>

        {/* Stats grid */}
        <motion.div
          className="grid grid-cols-2 gap-4 mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          {[
            { label: 'Final Score', value: stats.score.toLocaleString(), gradient: 'from-[#FF6B35] to-[#FFD23F]' },
            { label: 'Max Combo', value: stats.maxCombo, gradient: 'from-[#00D9FF] to-[#8338EC]' },
            { label: 'Total Hits', value: stats.hits, gradient: 'from-[#8338EC] to-[#FF006E]' },
            { label: 'Time', value: `${Math.floor(stats.timeElapsed / 1000)}s`, gradient: 'from-[#FFD23F] to-[#FF6B35]' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-2xl text-center group hover:bg-white/10 transition-colors"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              whileHover={{ scale: 1.05, y: -4 }}
            >
              <div className="text-white/40 text-xs tracking-widest uppercase mb-3">{stat.label}</div>
              <div className={`text-transparent bg-clip-text bg-gradient-to-r ${stat.gradient} text-4xl`}>
                {stat.value}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Motivational message */}
        <motion.div
          className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 mb-10 text-center rounded-2xl relative overflow-hidden group"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-[#00D9FF]/10 to-[#8338EC]/10 opacity-0 group-hover:opacity-100 transition-opacity"
          />
          <p className="text-white/80 italic text-xl relative z-10">{randomMessage}</p>
        </motion.div>

        {/* Action buttons */}
        <motion.div
          className="flex gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
        >
          <motion.button
            className="flex-1 flex items-center justify-center gap-3 px-8 py-5 bg-gradient-to-r from-[#FF6B35] to-[#FF006E] text-white rounded-2xl relative overflow-hidden group border border-white/20"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onPlayAgain}
          >
            <motion.div
              className="absolute inset-0 bg-white/20"
              initial={{ x: '-100%' }}
              whileHover={{ x: '100%' }}
              transition={{ duration: 0.5 }}
            />
            <RotateCcw className="w-5 h-5 relative z-10" />
            <span className="relative z-10 text-lg">Play Again</span>
          </motion.button>

          <motion.button
            className="flex-1 flex items-center justify-center gap-3 px-8 py-5 bg-white/10 text-white rounded-2xl backdrop-blur-xl border border-white/20 hover:bg-white/20 transition-colors"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onReturnToMenu}
          >
            <Home className="w-5 h-5" />
            <span className="text-lg">Main Menu</span>
          </motion.button>
        </motion.div>

        {/* Coin reward */}
        <motion.div
          className="mt-8 text-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1 }}
        >
          <motion.div 
            className="inline-flex items-center gap-3 bg-gradient-to-r from-[#FFD23F] to-[#FF6B35] px-8 py-4 rounded-2xl border-2 border-white/20 shadow-2xl"
            whileHover={{ scale: 1.05 }}
          >
            <Trophy className="w-6 h-6 text-white" />
            <span className="text-white text-lg">+{Math.floor(stats.score / 100)} coins earned</span>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}