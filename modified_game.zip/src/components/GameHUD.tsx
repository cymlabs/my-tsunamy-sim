import { motion } from 'motion/react';
import { X, Zap } from 'lucide-react';
import { GameMode, GameStats } from '../App';
import { useEffect, useState } from 'react';

interface GameHUDProps {
  stats: GameStats;
  gameMode: GameMode;
  onQuit: () => void;
}

export function GameHUD({ stats, gameMode, onQuit }: GameHUDProps) {
  const [timeRemaining, setTimeRemaining] = useState(60);

  useEffect(() => {
    if (gameMode === 'quick-vent') {
      const interval = setInterval(() => {
        const remaining = Math.max(0, 60 - Math.floor(stats.timeElapsed / 1000));
        setTimeRemaining(remaining);
      }, 100);
      return () => clearInterval(interval);
    }
  }, [gameMode, stats.timeElapsed]);

  const comboScale = Math.min(1 + (stats.combo * 0.03), 1.5);
  const comboOpacity = stats.combo > 0 ? 1 : 0.3;

  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 flex items-center justify-between p-6 pointer-events-auto">
        <div className="flex items-center gap-6">
          {/* Score */}
          <motion.div 
            className="bg-white/10 backdrop-blur-xl px-8 py-4 border border-white/20 rounded-2xl"
            whileHover={{ scale: 1.05 }}
          >
            <div className="text-white/50 text-xs tracking-widest uppercase mb-1">Score</div>
            <motion.div 
              className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD23F] text-3xl tabular-nums"
              key={stats.score}
              initial={{ scale: 1.3 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              {stats.score.toLocaleString()}
            </motion.div>
          </motion.div>

          {/* Timer (for Quick Vent mode) */}
          {gameMode === 'quick-vent' && (
            <motion.div 
              className="bg-white/10 backdrop-blur-xl px-8 py-4 border border-white/20 rounded-2xl"
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-white/50 text-xs tracking-widest uppercase mb-1">Time</div>
              <motion.div 
                className="text-3xl tabular-nums"
                style={{
                  color: timeRemaining < 10 ? '#FF006E' : 'white',
                }}
                animate={{ 
                  scale: timeRemaining < 10 && timeRemaining % 2 === 0 ? 1.15 : 1,
                }}
              >
                {timeRemaining}s
              </motion.div>
            </motion.div>
          )}
        </div>

        {/* Quit button */}
        <motion.button
          className="bg-white/10 backdrop-blur-xl p-4 border border-white/20 rounded-2xl hover:bg-white/20 transition-colors group"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onQuit}
        >
          <X className="w-6 h-6 text-white group-hover:text-[#FF006E] transition-colors" />
        </motion.button>
      </div>

      {/* Combo meter - center */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-3 pointer-events-none">
        <motion.div
          className="relative"
          animate={{ 
            scale: comboScale,
            opacity: comboOpacity,
          }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
        >
          {/* Glow rings */}
          {stats.combo > 0 && (
            <>
              <motion.div
                className="absolute inset-0 rounded-full blur-xl"
                style={{ 
                  background: 'radial-gradient(circle, #FF6B35, transparent)',
                }}
                animate={{ 
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 0.2, 0.5],
                }}
                transition={{ duration: 1, repeat: Infinity }}
              />
              <motion.div
                className="absolute inset-0 rounded-full blur-2xl"
                style={{ 
                  background: 'radial-gradient(circle, #00D9FF, transparent)',
                }}
                animate={{ 
                  scale: [1.5, 1, 1.5],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </>
          )}
          
          {/* Main icon */}
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-[#FF6B35] to-[#FF006E] flex items-center justify-center border-2 border-white/30">
            {stats.combo > 0 ? (
              <motion.div
                className="text-white text-2xl"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                key={stats.combo}
              >
                {stats.combo}
              </motion.div>
            ) : (
              <Zap className="w-10 h-10 text-white/50" />
            )}
          </div>
        </motion.div>
        
        {stats.combo > 0 && (
          <motion.div
            className="px-4 py-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="text-white text-sm tracking-wide">
              Combo ×{(1 + stats.combo * 0.1).toFixed(1)}
            </span>
          </motion.div>
        )}
      </div>

      {/* Bottom stats */}
      <div className="absolute bottom-0 left-0 right-0 p-6 pointer-events-auto">
        <div className="flex items-center justify-center gap-6">
          <motion.div 
            className="bg-white/10 backdrop-blur-xl px-6 py-3 border border-white/20 rounded-2xl text-center"
            whileHover={{ scale: 1.05 }}
          >
            <div className="text-white/50 text-xs tracking-widest uppercase mb-1">Hits</div>
            <div className="text-white text-xl">{stats.hits}</div>
          </motion.div>

          <motion.div 
            className="bg-white/10 backdrop-blur-xl px-6 py-3 border border-white/20 rounded-2xl text-center"
            whileHover={{ scale: 1.05 }}
          >
            <div className="text-white/50 text-xs tracking-widest uppercase mb-1">Max Combo</div>
            <div className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] to-[#8338EC] text-xl">
              {stats.maxCombo}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Progress bar for combo decay */}
      {stats.combo > 0 && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 w-80 max-w-[90vw]">
          <div className="h-2 bg-white/10 rounded-full overflow-hidden backdrop-blur-xl border border-white/20">
            <motion.div
              className="h-full bg-gradient-to-r from-[#FF6B35] via-[#FFD23F] to-[#00D9FF]"
              style={{ 
                boxShadow: '0 0 20px rgba(255, 107, 53, 0.5)',
              }}
              initial={{ width: '100%' }}
              animate={{ width: '0%' }}
              transition={{ duration: 2, ease: 'linear' }}
              key={stats.hits}
            />
          </div>
        </div>
      )}
    </div>
  );
}