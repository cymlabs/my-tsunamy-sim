import { useEffect } from 'react';
import { initializeSounds } from '../utils/sounds';

export function SoundManager() {
  useEffect(() => {
    initializeSounds();
  }, []);

  return null;
}
