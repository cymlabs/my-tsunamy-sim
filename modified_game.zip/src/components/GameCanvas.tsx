import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as THREE from 'three';
import { GameMode, GameStats } from '../App';
import { playSound } from '../utils/sounds';

interface GameCanvasProps {
  gameMode: GameMode;
  onGameEnd: (stats: GameStats) => void;
  onUpdateStats: (stats: GameStats) => void;
}

export function GameCanvas({ gameMode, onGameEnd, onUpdateStats }: GameCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    hits: 0,
    timeElapsed: 0,
  });
  const [hitEffects, setHitEffects] = useState<Array<{ id: number; x: number; y: number; damage: number; color: string }>>([]);
  const [buddyMessage, setBuddyMessage] = useState<string>('');
  const [messageColor, setMessageColor] = useState<string>('#FF6B35');
  const gameStateRef = useRef({
    lastHitTime: 0,
    comboTimer: 0,
    startTime: Date.now(),
  });

  useEffect(() => {
    if (!containerRef.current) return;

    // Three.js setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0a0a0a, 5, 15);
    
    const camera = new THREE.PerspectiveCamera(
      50,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    containerRef.current.appendChild(renderer.domElement);

    // Lighting - more dramatic
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);
    
    const spotLight = new THREE.SpotLight(0xFF6B35, 2);
    spotLight.position.set(5, 10, 5);
    spotLight.castShadow = true;
    scene.add(spotLight);

    const rimLight1 = new THREE.DirectionalLight(0x00D9FF, 1);
    rimLight1.position.set(-5, 2, -5);
    scene.add(rimLight1);

    const rimLight2 = new THREE.DirectionalLight(0xFF006E, 0.8);
    rimLight2.position.set(5, -2, -3);
    scene.add(rimLight2);

    // Create buddy character (more stylized and colorful)
    const buddyGroup = new THREE.Group();
    
    // Body with gradient-like effect using vertex colors
    const bodyGeometry = new THREE.CapsuleGeometry(1.2, 2.5, 16, 32);
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0xFF6B35,
      roughness: 0.6,
      metalness: 0.3,
      emissive: 0xFF6B35,
      emissiveIntensity: 0.2,
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    buddyGroup.add(body);

    // Head - more vibrant
    const headGeometry = new THREE.SphereGeometry(0.8, 32, 32);
    const headMaterial = new THREE.MeshStandardMaterial({
      color: 0xFFD23F,
      roughness: 0.5,
      metalness: 0.2,
      emissive: 0xFFD23F,
      emissiveIntensity: 0.15,
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 2;
    buddyGroup.add(head);

    // Eyes - glowing
    const eyeGeometry = new THREE.SphereGeometry(0.15, 16, 16);
    const eyeMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x00D9FF,
      emissive: 0x00D9FF,
      emissiveIntensity: 1,
    });
    
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-0.3, 2.2, 0.6);
    buddyGroup.add(leftEye);
    
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(0.3, 2.2, 0.6);
    buddyGroup.add(rightEye);

    // Ears - accent color
    const earGeometry = new THREE.SphereGeometry(0.3, 16, 16);
    const earMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x8338EC,
      roughness: 0.6,
      emissive: 0x8338EC,
      emissiveIntensity: 0.1,
    });
    
    const leftEar = new THREE.Mesh(earGeometry, earMaterial);
    leftEar.position.set(-0.7, 2.5, 0.2);
    buddyGroup.add(leftEar);
    
    const rightEar = new THREE.Mesh(earGeometry, earMaterial);
    rightEar.position.set(0.7, 2.5, 0.2);
    buddyGroup.add(rightEar);

    // Arms - gradient effect
    const armGeometry = new THREE.CapsuleGeometry(0.25, 1.2, 8, 16);
    const armMaterial = new THREE.MeshStandardMaterial({
      color: 0xFF006E,
      roughness: 0.7,
      metalness: 0.2,
      emissive: 0xFF006E,
      emissiveIntensity: 0.1,
    });
    
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-1.3, 0.5, 0);
    leftArm.rotation.z = Math.PI / 6;
    buddyGroup.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(1.3, 0.5, 0);
    rightArm.rotation.z = -Math.PI / 6;
    buddyGroup.add(rightArm);

    scene.add(buddyGroup);
    camera.position.z = 8;
    camera.position.y = 1;

    // Animation state
    let buddyRotation = { x: 0, y: 0, z: 0 };
    let targetRotation = { x: 0, y: 0, z: 0 };
    let squashStretch = 1;
    let glowIntensity = 0.2;

    // Game loop
    let animationId: number;
    const gameLoop = () => {
      const elapsed = Date.now() - gameStateRef.current.startTime;
      
      // Update combo decay
      const timeSinceLastHit = Date.now() - gameStateRef.current.lastHitTime;
      if (timeSinceLastHit > 2000 && stats.combo > 0) {
        setStats(prev => ({ ...prev, combo: 0 }));
      }

      // Check game end conditions
      if (gameMode === 'quick-vent' && elapsed > 60000) {
        onGameEnd({ ...stats, timeElapsed: elapsed });
        return;
      }

      // Smooth rotation
      buddyRotation.x += (targetRotation.x - buddyRotation.x) * 0.15;
      buddyRotation.y += (targetRotation.y - buddyRotation.y) * 0.15;
      buddyRotation.z += (targetRotation.z - buddyRotation.z) * 0.15;
      
      buddyGroup.rotation.x = buddyRotation.x;
      buddyGroup.rotation.y = buddyRotation.y;
      buddyGroup.rotation.z = buddyRotation.z;

      // Reset to idle
      targetRotation.x *= 0.9;
      targetRotation.y *= 0.9;
      targetRotation.z *= 0.9;

      // Squash and stretch
      squashStretch += (1 - squashStretch) * 0.1;
      body.scale.set(squashStretch, 1 / squashStretch, squashStretch);

      // Glow effect
      glowIntensity += (0.2 - glowIntensity) * 0.1;
      bodyMaterial.emissiveIntensity = glowIntensity;

      // Idle animation - gentle bob + rotation
      buddyGroup.position.y = Math.sin(elapsed * 0.002) * 0.15;
      buddyGroup.rotation.y += 0.002;

      // Animated lighting
      spotLight.intensity = 2 + Math.sin(elapsed * 0.001) * 0.5;

      renderer.render(scene, camera);
      animationId = requestAnimationFrame(gameLoop);
    };
    gameLoop();

    // Handle hits
    const handleHit = (event: MouseEvent | TouchEvent) => {
      event.preventDefault();
      
      const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX;
      const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY;

      // Calculate impact direction
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const deltaX = (clientX - centerX) / window.innerWidth;
      const deltaY = (clientY - centerY) / window.innerHeight;

      // Apply physics - more dramatic
      targetRotation.z = -deltaX * 0.8;
      targetRotation.x = deltaY * 0.5;
      squashStretch = 0.7;
      glowIntensity = 1;

      // Vibrate on supported devices
      if ('vibrate' in navigator) {
        navigator.vibrate(50);
      }

      // Update stats
      const timeSinceLastHit = Date.now() - gameStateRef.current.lastHitTime;
      const comboActive = timeSinceLastHit < 2000;
      
      const newCombo = comboActive ? stats.combo + 1 : 1;
      const comboMultiplier = Math.min(1 + (newCombo * 0.1), 5);
      const baseDamage = Math.floor(Math.random() * 50) + 50;
      const damage = Math.floor(baseDamage * comboMultiplier);
      
      setStats(prev => ({
        score: prev.score + damage,
        combo: newCombo,
        maxCombo: Math.max(prev.maxCombo, newCombo),
        hits: prev.hits + 1,
        timeElapsed: Date.now() - gameStateRef.current.startTime,
      }));

      gameStateRef.current.lastHitTime = Date.now();

      // Visual feedback - colorful
      const colors = ['#FF6B35', '#00D9FF', '#FFD23F', '#FF006E', '#8338EC'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      
      setHitEffects(prev => [...prev, { 
        id: Date.now() + Math.random(), 
        x: clientX, 
        y: clientY, 
        damage,
        color: randomColor,
      }]);
      
      setTimeout(() => {
        setHitEffects(prev => prev.slice(1));
      }, 1000);

      // Buddy messages based on combo
      const messages = [
        { texts: ["Ow!", "Hey!", "Oof!", "Yikes!"], color: '#FF6B35' },
        { texts: ["Keep going!", "That's it!", "Let it out!", "More!"], color: '#FFD23F' },
        { texts: ["Woah!", "Impressive!", "On fire!", "Amazing!"], color: '#00D9FF' },
        { texts: ["LEGENDARY!", "UNSTOPPABLE!", "GODLIKE!", "INSANE!"], color: '#FF006E' },
      ];
      
      const messageIndex = Math.min(Math.floor(newCombo / 5), messages.length - 1);
      const messageSet = messages[messageIndex];
      const randomMessage = messageSet.texts[Math.floor(Math.random() * messageSet.texts.length)];
      setBuddyMessage(randomMessage);
      setMessageColor(messageSet.color);
      setTimeout(() => setBuddyMessage(''), 1500);

      // Play sound
      if (newCombo > 10) {
        playSound('hit-heavy');
      } else if (newCombo > 5) {
        playSound('hit-medium');
      } else {
        playSound('hit-light');
      }
    };

    const canvas = renderer.domElement;
    canvas.addEventListener('mousedown', handleHit);
    canvas.addEventListener('touchstart', handleHit);

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      canvas.removeEventListener('mousedown', handleHit);
      canvas.removeEventListener('touchstart', handleHit);
      window.removeEventListener('resize', handleResize);
      containerRef.current?.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [gameMode, onGameEnd]);

  // Update parent with stats
  useEffect(() => {
    onUpdateStats(stats);
  }, [stats, onUpdateStats]);

  return (
    <div ref={containerRef} className="fixed inset-0 cursor-pointer">
      {/* Hit effects - more dynamic */}
      <AnimatePresence>
        {hitEffects.map(effect => (
          <motion.div
            key={effect.id}
            className="fixed pointer-events-none z-50 drop-shadow-2xl"
            style={{ 
              left: effect.x, 
              top: effect.y,
              color: effect.color,
              textShadow: `0 0 20px ${effect.color}`,
            }}
            initial={{ scale: 0.5, opacity: 1, y: 0, rotate: -10 }}
            animate={{ scale: 2, opacity: 0, y: -80, rotate: 10 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className="text-4xl font-bold">+{effect.damage}</span>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Buddy message - more stylized */}
      <AnimatePresence>
        {buddyMessage && (
          <motion.div
            className="fixed top-1/3 left-1/2 -translate-x-1/2 z-50 px-8 py-4 rounded-2xl backdrop-blur-xl border-2"
            style={{
              background: `linear-gradient(135deg, ${messageColor}20, ${messageColor}10)`,
              borderColor: messageColor,
              boxShadow: `0 0 40px ${messageColor}60`,
            }}
            initial={{ scale: 0, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          >
            <motion.span 
              className="text-white text-3xl"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.3 }}
            >
              {buddyMessage}
            </motion.span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}